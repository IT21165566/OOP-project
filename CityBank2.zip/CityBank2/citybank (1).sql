-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2022 at 12:24 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `citybank`
--

-- --------------------------------------------------------

--
-- Table structure for table `billpay`
--

CREATE TABLE `billpay` (
  `billnumber` int(30) NOT NULL,
  `billtype` varchar(40) NOT NULL,
  `payeename` varchar(50) NOT NULL,
  `accountNo` int(20) NOT NULL,
  `amount` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `billpay`
--

INSERT INTO `billpay` (`billnumber`, `billtype`, `payeename`, `accountNo`, `amount`) VALUES
(12, 'water', 'senera', 1234898653, 200),
(14, 'Internet', 'Ann', 7896523, 5520),
(45, 'water', 'rgthjr', 1358, 10),
(78, 'Internet', 'Dudu', 123456789, 100),
(123, 'water', 'ravidu', 12748596, 3220),
(147, 'water', 'hi', 78945612, 159),
(1234567, 'sdfghj', 'sdfghj', 12345, 12345);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `AccountNumber` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `NIC` varchar(100) NOT NULL,
  `E-Mail` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Phone Number` varchar(100) NOT NULL,
  `DOB` varchar(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Occupation` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login_details`
--

CREATE TABLE `login_details` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_details`
--

INSERT INTO `login_details` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `paymentportal`
--

CREATE TABLE `paymentportal` (
  `amt` float NOT NULL,
  `cardName` varchar(500) NOT NULL,
  `cardNo` int(11) NOT NULL,
  `cvv` int(11) NOT NULL,
  `expireD` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `paymentportal`
--

INSERT INTO `paymentportal` (`amt`, `cardName`, `cardNo`, `cvv`, `expireD`) VALUES
(100, 'wertyuiolknh', 12698745, 12398, '2012-12-12'),
(200, 'kjknlkm', 123475, 111, '2011-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE `transfer` (
  `uname` varchar(100) NOT NULL,
  `accno` int(40) NOT NULL,
  `amounts` varchar(100) NOT NULL,
  `curr` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `def` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transfer`
--

INSERT INTO `transfer` (`uname`, `accno`, `amounts`, `curr`, `email`, `bank`, `def`) VALUES
('nimal', 12345, '100.00', 'LKR', 'nimal@gmail.com', 'no', 'boc'),
('nimal', 12345, '100.00', 'LKR', 'nimal12@gmai.com', 'no', 'boc'),
('nimal', 12345, '100.00', 'LRK', 'nimal123@gmail.com', 'no', 'boc'),
('kamal', 12345, '100.00', 'LKR', 'nimal123@gmail.com', 'no', 'boc');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billpay`
--
ALTER TABLE `billpay`
  ADD PRIMARY KEY (`billnumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billpay`
--
ALTER TABLE `billpay`
  MODIFY `billnumber` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1234568;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
